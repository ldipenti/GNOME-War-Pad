/* File: kmkturn.c
 *
 * K-MakeTurn is a newer and faster version for Tim Wisseman's VGA-Planets.
 * Distillates a ``PLAYER??.TRN'' from *.DAT and *.DIS
 *
 * Author: Kero van Gelder
 * First version: 3 XII 1995
 * Last revision: 1 VI 1998
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"
#include "playerio.h"

#define version "1.3a"

unsigned short inornot[11]; /* Player X in or not? (init.tmp) */
unsigned char *trnbuf,*trnremember[11],*fizzremember;
unsigned long size[11],cs[11];

FILE *ResetPlayerFile(prefix,nr,suffix)
char *prefix,*nr,*suffix;
{
  char *filename;
  FILE *f;
  
  filename=malloc(strlen(gamedir)+strlen(prefix)+strlen(nr)+1+strlen(suffix)+1);
  sprintf(filename,"%s%s%s.%s",gamedir,prefix,nr,suffix);
  f=fopen(filename,"rb");
  if (f==NULL) {
    #ifdef test
    fprintf(stderr,"No file %s, trying capital version...\n",filename);
    #endif
    StrToUpper(prefix);
    StrToUpper(suffix);
    sprintf(filename,"%s%s%s.%s",gamedir,prefix,nr,suffix);
    f=fopen(filename,"rb");
    if (f==NULL) {
      fprintf(stderr,"No file %s available!\n\n",filename);
      exit(-1);
    }
  }
  #ifdef test
  fprintf(stderr,"Opened file %s\n",filename);
  #endif
  return f;
}

#define NewCommand(sizeofcommand,whatcommand) { \
  commptr=realloc(commptr,sizeof(long)*(nocommands+1));\
  commptr[nocommands]=commsize;\
  nocommands++;\
  commremember=realloc(commremember,commsize+sizeofcommand);\
  commbuf=commremember;\
  commbuf+=commsize;\
  WriteShort(whatcommand,commbuf);\
  commsize+=sizeofcommand;\
}

long PerformCommands(p)
short p;
{
  long nocommands=0,commsize=0,replacement;
  unsigned long *commptr=NULL;
  unsigned char *commremember=NULL,*commbuf,*trnbuf;
  long i,j;
  oneship *olds, *news;
  oneplanet *oldp, *newp;
  onebase *oldb, *newb;
  boolean build;

  /* commands for all ships */
  fprintf(stdout,"%3d ships found\n",newship->noships);
  for (i=0;i<oldship->noships;i++) {
    olds=oldship->ship[i];
    news=newship->ship[i];
    #ifdef test
    fprintf(stderr,"%ld",i%10);
    #endif
    if (strncmp(olds->fc,news->fc,3)) {
      NewCommand(7,1);
      WriteShort(news->nr,commbuf);
      memcpy(commbuf,news->fc,3);
      commbuf+=3;
    }
    if (olds->warp!=news->warp) {
      NewCommand(6,2);
      WriteShort(news->nr,commbuf);
      WriteShort(news->warp,commbuf);
    }
    if ((olds->dx!=news->dx)||(olds->dy!=news->dy)) {
      NewCommand(8,3);
      WriteShort(news->nr,commbuf);
      WriteShort(news->dx,commbuf);
      WriteShort(news->dy,commbuf);
    }
    if (olds->mission!=news->mission) {
      NewCommand(6,4);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mission,commbuf);
    }
    if (olds->enemy!=news->enemy) {
      NewCommand(6,5);
      WriteShort(news->nr,commbuf);
      WriteShort(news->enemy,commbuf);
    }
    if (olds->towtarget!=news->towtarget) {
      NewCommand(6,6);
      WriteShort(news->nr,commbuf);
      WriteShort(news->towtarget,commbuf);
    }
    if (olds->inttarget!=news->inttarget) {
      NewCommand(6,10);
      WriteShort(news->nr,commbuf);
      WriteShort(news->inttarget,commbuf);
    }
    if (strncmp(olds->name,news->name,20)) {
      NewCommand(24,7);
      WriteShort(news->nr,commbuf);
      memcpy(commbuf,news->name,20);
      commbuf+=20;
    }
    if ((olds->planettopl!=news->planettopl)||
	(olds->fueltopl!=news->fueltopl)||(olds->trittopl!=news->trittopl)||
	(olds->durtopl!=news->durtopl)||(olds->molybtopl!=news->molybtopl)||
	(olds->clanstopl!=news->clanstopl)||(olds->supptopl!=news->supptopl)) {
      NewCommand(18,8);
      WriteShort(news->nr,commbuf);
      WriteShort(news->fueltopl,commbuf);
      WriteShort(news->trittopl,commbuf);
      WriteShort(news->durtopl,commbuf);
      WriteShort(news->molybtopl,commbuf);
      WriteShort(news->clanstopl,commbuf);
      WriteShort(news->supptopl,commbuf);
      WriteShort(news->planettopl,commbuf);
    }
    if ((olds->shiptosh!=news->shiptosh)||
	(olds->fueltosh!=news->fueltosh)||(olds->trittosh!=news->trittosh)||
	(olds->durtosh!=news->durtosh)||(olds->molybtosh!=news->molybtosh)||
	(olds->clanstosh!=news->clanstosh)||(olds->supptosh!=news->supptosh)) {
      NewCommand(18,9);
      WriteShort(news->nr,commbuf);
      WriteShort(news->fueltosh,commbuf);
      WriteShort(news->trittosh,commbuf);
      WriteShort(news->durtosh,commbuf);
      WriteShort(news->molybtosh,commbuf);
      WriteShort(news->clanstosh,commbuf);
      WriteShort(news->supptosh,commbuf);
      WriteShort(news->shiptosh,commbuf);
    }
    if (olds->mineral[neutr]!=news->mineral[neutr]) {
      NewCommand(6,11);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mineral[neutr],commbuf);
    }
    if (olds->mineral[trit]!=news->mineral[trit]) {
      NewCommand(6,12);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mineral[trit],commbuf);
    }
    if (olds->mineral[dur]!=news->mineral[dur]) {
      NewCommand(6,13);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mineral[dur],commbuf);
    }
    if (olds->mineral[molyb]!=news->mineral[molyb]) {
      NewCommand(6,14);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mineral[molyb],commbuf);
    }
    if (olds->supp!=news->supp) {
      NewCommand(6,15);
      WriteShort(news->nr,commbuf);
      WriteShort(news->supp,commbuf);
    }
    if (olds->nocol!=news->nocol) {
      NewCommand(6,16);
      WriteShort(news->nr,commbuf);
      WriteShort(news->nocol,commbuf);
    }
    if (olds->notorps!=news->notorps) {
      NewCommand(6,17);
      WriteShort(news->nr,commbuf);
      WriteShort(news->notorps,commbuf);
    }
    if (olds->mc!=news->mc) {
      NewCommand(6,18);
      WriteShort(news->nr,commbuf);
      WriteShort(news->mc,commbuf);
    }
  }

  /* commands for all planets */
  fprintf(stdout,"%3d planets found\n",newplanet->noplanets);
  for (i=0;i<newplanet->noplanets;i++) {
    oldp=oldplanet->planet[i];
    newp=newplanet->planet[i];
    #ifdef test
    fprintf(stderr,"%ld",i%10);
    #endif
    if (strncmp(oldp->fc,newp->fc,3)) {
      NewCommand(7,21);
      WriteShort(newp->nr,commbuf);
      memcpy(commbuf,newp->fc,3);
      commbuf+=3;
    }
    if (oldp->mines!=newp->mines) {
      NewCommand(6,22);
      WriteShort(newp->nr,commbuf);
      WriteShort(newp->mines,commbuf);
    }
    if (oldp->fact!=newp->fact) {
      NewCommand(6,23);
      WriteShort(newp->nr,commbuf);
      WriteShort(newp->fact,commbuf);
    }
    if (oldp->defense!=newp->defense) {
      NewCommand(6,24);
      WriteShort(newp->nr,commbuf);
      WriteShort(newp->defense,commbuf);
    }
    if (oldp->mined[neutr]!=newp->mined[neutr]) {
      NewCommand(8,25);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->mined[neutr],commbuf);
    }
    if (oldp->mined[trit]!=newp->mined[trit]) {
      NewCommand(8,26);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->mined[trit],commbuf);
    }
    if (oldp->mined[dur]!=newp->mined[dur]) {
      NewCommand(8,27);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->mined[dur],commbuf);
    }
    if (oldp->mined[molyb]!=newp->mined[molyb]) {
      NewCommand(8,28);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->mined[molyb],commbuf);
    }
    if (oldp->nocol!=newp->nocol) {
      NewCommand(8,29);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->nocol,commbuf);
    }
    if (oldp->supp!=newp->supp) {
      NewCommand(8,30);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->supp,commbuf);
    }
    if (oldp->mc!=newp->mc) {
      NewCommand(8,31);
      WriteShort(newp->nr,commbuf);
      WriteLong(newp->mc,commbuf);
    }
    if (oldp->coltax!=newp->coltax) {
      NewCommand(6,32);
      WriteShort(newp->nr,commbuf);
      WriteShort(newp->coltax,commbuf);
    }
    if (oldp->nattax!=newp->nattax) {
      NewCommand(6,33);
      WriteShort(newp->nr,commbuf);
      WriteShort(newp->nattax,commbuf);
    }
    if (newp->buildbase) {
      NewCommand(4,34);
      WriteShort(newp->nr,commbuf);
    }
  }

  /* commands for all bases */
  fprintf(stdout,"%3d bases found\n",newbase->nobases);
  for (i=0;i<newbase->nobases;i++) {
    oldb=oldbase->base[i];
    newb=newbase->base[i];
    #ifdef test
    fprintf(stderr,"%ld",i%10);
    #endif
    if (oldb->defense!=newb->defense) {
      NewCommand(6,40);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->defense,commbuf);
    }
    if (oldb->engtech!=newb->engtech) {
      NewCommand(6,41);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->engtech,commbuf);
    }
    if (oldb->hulltech!=newb->hulltech) {
      NewCommand(6,42);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->hulltech,commbuf);
    }
    if (oldb->beamtech!=newb->beamtech) {
      NewCommand(6,43);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->beamtech,commbuf);
    }
    build=false;
    for (j=0;j<noe;j++) build+=(oldb->noengines[j]!=newb->noengines[j]);
    if (build) {
      NewCommand(22,44);
      WriteShort(newb->nr,commbuf);
      for (j=0;j<noe;j++) { WriteShort(newb->noengines[j],commbuf); }
    }
    build=false;
    for (j=0;j<20;j++) build+=(oldb->nohulls[j]!=newb->nohulls[j]);
    if (build) {
      NewCommand(44,45);
      WriteShort(newb->nr,commbuf);
      for (j=0;j<20;j++) { WriteShort(newb->nohulls[j],commbuf); }
    }
    build=false;
    for (j=0;j<nob;j++) build+=(oldb->nobeams[j]!=newb->nobeams[j]);
    if (build) {
      NewCommand(24,46);
      WriteShort(newb->nr,commbuf);
      for (j=0;j<nob;j++) { WriteShort(newb->nobeams[j],commbuf); }
    }
    build=false;
    for (j=0;j<notp;j++) build+=(oldb->nolaunch[j]!=newb->nolaunch[j]);
    if (build) {
      NewCommand(24,47);
      WriteShort(newb->nr,commbuf);
      for (j=0;j<notp;j++) { WriteShort(newb->nolaunch[j],commbuf); }
    }
    build=false;
    for (j=0;j<notp;j++) build+=(oldb->notorps[j]!=newb->notorps[j]);
    if (build) {
      NewCommand(24,48);
      WriteShort(newb->nr,commbuf);
      for (j=0;j<notp;j++) { WriteShort(newb->notorps[j],commbuf); }
    }
    if (oldb->nofighters!=newb->nofighters) {
      NewCommand(6,49);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->nofighters,commbuf);
    }
    if (oldb->target!=newb->target) {
      NewCommand(6,50);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->target,commbuf);
    }
    if (oldb->fixrec!=newb->fixrec) {
      NewCommand(6,51);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->fixrec,commbuf);
    }
    if (oldb->mission!=newb->mission) {
      NewCommand(6,52);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->mission,commbuf);
    }
    if ( ((newb->bhulltype!=0) && (newb->bengtype!=0)) &&
	((oldb->bhulltype!=newb->bhulltype) || (oldb->bengtype!=newb->bengtype)) ) {
      NewCommand(18,53);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->bhulltype,commbuf);
      WriteShort(newb->bengtype,commbuf);
      WriteShort(newb->bbeamtype,commbuf);
      WriteShort(newb->bnobeams,commbuf);
      WriteShort(newb->btorptype,commbuf);
      WriteShort(newb->bnolaunch,commbuf);
      WriteShort(0,commbuf); /* What's this? Not fighterbays */
    }
    if (oldb->torptech!=newb->torptech) {
      NewCommand(6,54);
      WriteShort(newb->nr,commbuf);
      WriteShort(newb->torptech,commbuf);
    }
  }

  /* other commands */
  fprintf(stdout,"%3d messages found\n",newmess->nomess);
  for (i=0;i<newmess->nomess;i++) {
    NewCommand(newmess->mess[i]->messlen+8,60);
    WriteShort(newmess->mess[i]->messlen,commbuf);
    WriteShort(p,commbuf); /* from who could a message be? */
    WriteShort(newmess->mess[i]->to,commbuf);
    memcpy(commbuf,newmess->mess[i]->message,newmess->mess[i]->messlen);
    for (j=0;j<newmess->mess[i]->messlen;j++) commbuf[j]+=13;
    commbuf+=newmess->mess[i]->messlen;
  };
  if (gen.changepw) {
    fprintf(stdout,"New password found\n");
    NewCommand(14,61);
    WriteShort(0,commbuf);
    memcpy(commbuf,gen.newpw,10);
    commbuf+=10;
  }

  if (nocommands!=0) {
    trnremember[p-1]=realloc(trnremember[p-1],size[p-1]+4*nocommands+commsize+1);
    replacement=size[p-1]+4*nocommands+1+1; /* this sucks and is foolish */
    trnbuf=trnremember[p-1]+size[p-1];
    trnbuf[0]=0; /* Why inserting one useless byte */
    trnbuf++;    /* when there are commands? Tim?  */
    for (i=0;i<nocommands;i++) {
      commptr[i]+=replacement;
      WriteLong(commptr[i],trnbuf);
    }
    memcpy(trnbuf,commremember,commsize);
    size[p-1]+=1+4*nocommands+commsize;
    free(commptr);
    free(commremember);
  }
  return nocommands;
}
#undef newCommand(xxx)

void MakeTurn(p)
short p;
{
  long nocommands=0;
  unsigned int i;

  fprintf(stdout,"Making turn %d for player %d in game %s...\n",gen.turnnr,p,gamedir);
  trnremember[p-1]=malloc(28); /* playernr, #commands, timestamp, 00, gameid */
  trnbuf=trnremember[p-1];
  WriteShort(p,trnbuf);
  WriteLong(nocommands,trnbuf);
  memcpy(trnbuf,gen.timestamp,18);
  trnbuf+=18;
  WriteShort(0,trnbuf); /* two bytes, sometimes 0, seem meaningless */
  WriteShort(gen.gameid,trnbuf);
  size[p-1]=28;
  nocommands=PerformCommands(p);
  fprintf(stdout,"%3ld commands\n\n",nocommands);
  trnbuf=trnremember[p-1]+2;
  WriteLong(nocommands,trnbuf);
  cs[p-1]=13; /* 13 added to total checksum */
  for (i=0;i<size[p-1];i++) cs[p-1]+=trnremember[p-1][i];
  for (i=6;i<24;i++) cs[p-1]+=(3*trnremember[p-1][i]); /* timestamp 4x in checksum; Why, Tim? */
  trnremember[p-1]=realloc(trnremember[p-1],size[p-1]+4+4+sof+44);
  trnbuf=trnremember[p-1]+size[p-1];
  WriteLong(cs[p-1],trnbuf);
  memcpy(trnbuf,"Kero",4); /* Personal touch */
  trnbuf+=4;
  memcpy(trnbuf,fizzremember,sof);
  trnbuf+=sof;
  size[p-1]+=4+4+sof; /* checksum, "Kero" and fizz */
  free(player);
  fprintf(stdout,"Done!\n\n");
}

void WriteTurns()
{
  FILE *trn;
  char *trnname;
  int i,j;
  
  /* 11 checksums (ALL races) for checking same-directory (host!) */
  for (i=0;i<11;i++) if (inornot[i]) {
    trnbuf=trnremember[i];
    trnbuf+=size[i];
    for (j=0;j<11;j++) {
      WriteLong(cs[j],trnbuf);
    }
    size[i]+=4*11;
    trnname=malloc(strlen(gamedir)+6+2+4+1);
    sprintf(trnname,"%splayer%d.trn",gamedir,i+1);
    trn=fopen(trnname,"wb");
    fwrite(trnremember[i],size[i],1,trn);
    fclose(trn);
    free(trnname);
    #ifdef test
    fprintf(stderr,"player%d.trn written\n",i+1);
    #endif
  } else {
    #ifdef test
    fprintf(stderr,"player %d does not play in game %s\n",i+1,gamedir);
    #endif
  }
}

int main(argc,argv)
int argc;
char *argv[];
{
  FILE *init,*fizz;
  short i;

  fprintf(stdout,"\nkmkturn %s made by Kero van Gelder, "
	  "%s\n",version,email);
  fprintf(stdout,"THE maketurn-utility for Tim wissemans VGA-planets.\n\n");
  if (argc!=2) {
    fprintf(stderr,"Usage: kmkturn <gamedir>\n\n");
    exit(1);
  }
  SetPlanetsDir(".");
  SetGameDir(argv[1]);
  GlobalInit();
  fizz=ResetPlayerFile("fizz","","bin");
  fizzremember=malloc(sof);
  fseek(fizz,136,SEEK_SET); /* The place where the registration part starts */
  fread(fizzremember,sof,1,fizz);
  fclose(fizz);
  init=ResetPlayerFile("init","","tmp");
  fread(inornot,2,11,init);
  fclose(init);
  for (i=0;i<11;i++) {
    if (inornot[i]) {
      SetPlayer(i+1);
      PlayerioInit();
      MakeTurn(i+1);
    }
  }
  WriteTurns();
  free(fizzremember);
  #ifdef test
  fprintf(stderr,"Really done now.\n");
  #endif
  return(0);
}
